module.exports = {
    plugins: [
        require("./node_modules/postcss-import"),
        require("./node_modules/tailwindcss"),
        require("./node_modules/autoprefixer"),
    ],
};